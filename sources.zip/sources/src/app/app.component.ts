import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';


export interface Record {
  date: string;
  topic: string;
}

const MOCK_DATA: Record[] = [
  { date: '10-10-2000', topic: "A" },
  { date: '15-10-2000', topic: "B" },
  { date: '20-10-2000', topic: "C" },
];

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  title = 'singleshipment';

  dateFactor: any
  topicFactor: any

  filterBy() {
    
  }
  

  displayedColumns: string[] = ['date', 'topic'];
  dataSource = new MatTableDataSource(MOCK_DATA);

  @ViewChild(MatSort) sort = new MatSort();

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }



  

}
