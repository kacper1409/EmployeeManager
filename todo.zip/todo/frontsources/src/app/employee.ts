export interface Employee {
    id: number;
    name: string;
    role: string;    
}